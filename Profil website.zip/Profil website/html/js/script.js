// Profile image URL und Biografie - Ändere diese Werte
const PROFILE_IMAGE_URL = 'https://sxtn.isfucking.pro/Oc1Zmn.jpg';
const BIOGRAPHY_TEXT = `Hallo! Ich bin Loryx und liebe es, kreative Inhalte zu erstellen. 
Ich beschäftige mich gerne mit Technologie, Gaming.`;

// Load profile image
function loadProfileImage() {
    const profileImageContainer = document.getElementById('profileImage');
    const img = new Image();
    
    img.onload = function() {
        profileImageContainer.innerHTML = '';
        img.style.opacity = '0';
        profileImageContainer.appendChild(img);
        
        // Fade in the image
        setTimeout(() => {
            img.style.opacity = '1';
            img.style.transition = 'opacity 0.5s ease-in-out';
        }, 100);
    };
    
    img.onerror = function() {
        profileImageContainer.innerHTML = '<div class="image-error">Bild konnte nicht geladen werden</div>';
    };
    
    img.src = PROFILE_IMAGE_URL;
    img.alt = 'Loryx Profilbild';
}

// Load biography
function loadBiography() {
    const biographyElement = document.getElementById('biographyText');
    biographyElement.textContent = BIOGRAPHY_TEXT;
}

// Create animated network background
function createNetworkBackground() {
    const container = document.getElementById('networkBg');
    const nodeCount = 80;
    const particleCount = 30;
    const nodes = [];

    // Create floating nodes
    for (let i = 0; i < nodeCount; i++) {
        const node = document.createElement('div');
        node.className = 'node';
        node.style.left = Math.random() * 100 + '%';
        node.style.top = Math.random() * 100 + '%';
        node.style.animationDelay = Math.random() * 6 + 's';
        node.style.animationDuration = (4 + Math.random() * 4) + 's';
        container.appendChild(node);
        nodes.push({
            element: node,
            x: parseFloat(node.style.left),
            y: parseFloat(node.style.top)
        });
    }

    // Create connecting lines with better algorithm
    for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
            const dx = nodes[i].x - nodes[j].x;
            const dy = nodes[i].y - nodes[j].y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 25 && Math.random() > 0.6) {
                const line = document.createElement('div');
                line.className = 'line';
                
                const angle = Math.atan2(dy, dx) * 180 / Math.PI;
                const length = distance;
                
                line.style.left = nodes[j].x + '%';
                line.style.top = nodes[j].y + '%';
                line.style.width = length + 'vw';
                line.style.transform = `rotate(${angle}deg)`;
                line.style.transformOrigin = '0 50%';
                line.style.animationDelay = Math.random() * 8 + 's';
                line.style.animationDuration = (6 + Math.random() * 4) + 's';
                
                container.appendChild(line);
            }
        }
    }

    // Create floating particles
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 15 + 's';
        particle.style.animationDuration = (10 + Math.random() * 10) + 's';
        container.appendChild(particle);
    }

    // Continuously update node positions for dynamic connections
    setInterval(() => {
        updateConnections(container, nodes);
    }, 3000);
}

function updateConnections(container, nodes) {
    // Remove old lines
    const oldLines = container.querySelectorAll('.line');
    oldLines.forEach(line => line.remove());

    // Create new random connections
    const connectionCount = Math.floor(Math.random() * 20) + 10;
    
    for (let i = 0; i < connectionCount; i++) {
        const node1 = nodes[Math.floor(Math.random() * nodes.length)];
        const node2 = nodes[Math.floor(Math.random() * nodes.length)];
        
        if (node1 !== node2) {
            const dx = node1.x - node2.x;
            const dy = node1.y - node2.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 40) {
                const line = document.createElement('div');
                line.className = 'line';
                
                const angle = Math.atan2(dy, dx) * 180 / Math.PI;
                
                line.style.left = node2.x + '%';
                line.style.top = node2.y + '%';
                line.style.width = distance + 'vw';
                line.style.transform = `rotate(${angle}deg)`;
                line.style.transformOrigin = '0 50%';
                line.style.opacity = '0';
                line.style.animation = 'flow 4s ease-in-out';
                
                container.appendChild(line);
            }
        }
    }
}

// Initialize everything when page loads
function initializeProfile() {
    loadProfileImage();
    loadBiography();
    createNetworkBackground();
    initializeCursor();
    initializeSocialLinks();
    initializeKeyboardDisabling();
}

// Custom cursor functionality
function initializeCursor() {
    const cursor = document.getElementById('cursor');

    // Track mouse position and update cursor immediately
    document.addEventListener('mousemove', (e) => {
        cursor.style.left = e.clientX - 10 + 'px';
        cursor.style.top = e.clientY - 10 + 'px';
    });

    // Cursor hover effects (only for profile image)
    const hoverElements = document.querySelectorAll('.profile-image');
    
    hoverElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            cursor.classList.add('hover');
        });
        
        element.addEventListener('mouseleave', () => {
            cursor.classList.remove('hover');
        });
    });

    // Cursor click effect
    document.addEventListener('mousedown', () => {
        cursor.classList.add('click');
    });

    document.addEventListener('mouseup', () => {
        cursor.classList.remove('click');
    });

    // Hide cursor when leaving window
    document.addEventListener('mouseleave', () => {
        cursor.style.opacity = '0';
    });

    document.addEventListener('mouseenter', () => {
        cursor.style.opacity = '1';
    });

    // Disable right-click context menu
    document.addEventListener('contextmenu', (e) => {
        e.preventDefault();
    });

    // Disable drag and drop
    document.addEventListener('dragstart', (e) => {
        e.preventDefault();
    });
}

// Social links functionality
function initializeSocialLinks() {
    // Add click effects to social links
    document.querySelectorAll('.social-link').forEach(link => {
        link.addEventListener('click', function(e) {
            // Don't prevent default - let links work normally
            
            // Create ripple effect
            const ripple = document.createElement('div');
            ripple.style.position = 'absolute';
            ripple.style.borderRadius = '50%';
            ripple.style.background = 'rgba(255, 255, 255, 0.3)';
            ripple.style.transform = 'scale(0)';
            ripple.style.animation = 'ripple 0.6s linear';
            ripple.style.left = '50%';
            ripple.style.top = '50%';
            ripple.style.width = '20px';
            ripple.style.height = '20px';
            ripple.style.marginLeft = '-10px';
            ripple.style.marginTop = '-10px';
            ripple.style.pointerEvents = 'none';
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
}

// Disable keyboard shortcuts
function initializeKeyboardDisabling() {
    // Disable text selection with keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Disable Ctrl+A, Ctrl+S, Ctrl+C, F12, etc.
        if (e.ctrlKey && (e.key === 'a' || e.key === 'c' || e.key === 's' || e.key === 'u')) {
            e.preventDefault();
        }
        // Disable F12 (Developer Tools)
        if (e.key === 'F12') {
            e.preventDefault();
        }
        // Disable Ctrl+Shift+I (Developer Tools)
        if (e.ctrlKey && e.shiftKey && e.key === 'I') {
            e.preventDefault();
        }
    });
}

// Start everything when page loads
window.addEventListener('load', initializeProfile);